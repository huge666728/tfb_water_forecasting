"""
PatchTST - Target-Specific Channel Selection (39维水厂数据适配版)

特征顺序 (去掉date后38维，索引0-37):
0:  总原水流量
1:  原水ph
2:  原水浊度
3:  1#滤前水浊度        <- 目标1
4:  1#滤格液位
5:  2#滤格液位
6:  3#滤格液位
7:  4#滤格液位
8:  5#滤格液位
9:  6#滤格液位
10: 1#滤格清水阀开度
11: 2#滤格清水阀开度
12: 3#滤格清水阀开度
13: 4#滤格清水阀开度
14: 5#滤格清水阀开度
15: 6#滤格清水阀开度
16: 一期滤后水浊度      <- 目标2
17: 二期滤前水浊度      <- 目标3
18: 二期1#滤格液位
19: 二期2#滤格液位
20: 二期3#滤格液位
21: 二期4#滤格液位
22: 二期5#滤格液位
23: 二期6#滤格液位
24: 二期1#滤格出水阀开度
25: 二期2#滤格出水阀开度
26: 二期3#滤格出水阀开度
27: 二期4#滤格出水阀开度
28: 二期5#滤格出水阀开度
29: 二期6#滤格出水阀开度
30: 清水池水位
31: 出厂压力
32: 出厂余氯            <- 目标4
33: 出厂ph              <- 目标5
34: 出厂浊度            <- 目标6
35: 出厂流量
36: dose_hour
37: dose_state

可见通道定义（包含目标间的因果关系）:
- 1#滤前水浊度(3): 原水+dose = [0,1,2,36,37]
- 二期滤前水浊度(17): 原水+dose = [0,1,2,36,37]
- 一期滤后水浊度(16): 原水+1#滤前+二期滤前+一期滤格+dose = [0,1,2,3,4-15,17,36,37]
- 出厂余氯(32): 全部上游+滤前+滤后 = [0-31,35,36,37]
- 出厂ph(33): 全部上游+滤前+滤后 = [0-31,35,36,37]
- 出厂浊度(34): 全部上游+滤前+滤后 = [0-31,35,36,37]
"""

import torch
from torch import nn
import torch.nn.functional as F

# TFB框架兼容导入
try:
    from ..layers.Embed import PatchEmbedding
    from ..layers.SelfAttention_Family import FullAttention, AttentionLayer
    from ..layers.Transformer_EncDec import Encoder, EncoderLayer
except ImportError:
    PatchEmbedding = None
    FullAttention = None
    AttentionLayer = None
    Encoder = None
    EncoderLayer = None

# =========================
# 特征索引常量定义 (39维数据，去掉date后38维)
# =========================
FEATURE_NAMES = [
    "总原水流量",  # 0
    "原水ph",  # 1
    "原水浊度",  # 2
    "1#滤前水浊度",  # 3  <- 目标
    "1#滤格液位",  # 4
    "2#滤格液位",  # 5
    "3#滤格液位",  # 6
    "4#滤格液位",  # 7
    "5#滤格液位",  # 8
    "6#滤格液位",  # 9
    "1#滤格清水阀开度",  # 10
    "2#滤格清水阀开度",  # 11
    "3#滤格清水阀开度",  # 12
    "4#滤格清水阀开度",  # 13
    "5#滤格清水阀开度",  # 14
    "6#滤格清水阀开度",  # 15
    "一期滤后水浊度",  # 16 <- 目标
    "二期滤前水浊度",  # 17 <- 目标
    "二期1#滤格液位",  # 18
    "二期2#滤格液位",  # 19
    "二期3#滤格液位",  # 20
    "二期4#滤格液位",  # 21
    "二期5#滤格液位",  # 22
    "二期6#滤格液位",  # 23
    "二期1#滤格出水阀开度",  # 24
    "二期2#滤格出水阀开度",  # 25
    "二期3#滤格出水阀开度",  # 26
    "二期4#滤格出水阀开度",  # 27
    "二期5#滤格出水阀开度",  # 28
    "二期6#滤格出水阀开度",  # 29
    "清水池水位",  # 30
    "出厂压力",  # 31
    "出厂余氯",  # 32 <- 目标
    "出厂ph",  # 33 <- 目标
    "出厂浊度",  # 34 <- 目标
    "出厂流量",  # 35
    "dose_hour",  # 36
    "dose_state",  # 37
]

# 目标特征索引
TARGET_INDICES = [3, 16, 17, 32, 33, 34]
TARGET_NAMES = ["1#滤前水浊度", "一期滤后水浊度", "二期滤前水浊度", "出厂余氯", "出厂ph", "出厂浊度"]

# 原水特征索引
RAW_INDICES = [0, 1, 2]

# 加药特征索引
DOSE_INDICES = [36, 37]

# 一期滤格特征索引 (液位+阀门开度)
PHASE1_FILTER_INDICES = list(range(4, 16))  # 4-15

# 二期滤格特征索引 (液位+阀门开度)
PHASE2_FILTER_INDICES = list(range(18, 30))  # 18-29

# =========================
# 可见通道定义（包含目标间因果关系）
# =========================
VISIBLE_CHANNELS = {
    # 1#滤前水浊度: 原水 + dose + 自己
    3: [0, 1, 2, 3, 36, 37],

    # 二期滤前水浊度: 原水 + dose + 自己
    17: [0, 1, 2, 17, 36, 37],

    # 一期滤后水浊度: 原水 + 1#滤前(3) + 二期滤前(17) + 一期滤格(4-15) + dose + 自己
    16: [0, 1, 2, 3, 17] + list(range(4, 16)) + [16, 36, 37],

    # 出厂余氯: 全部上游 (不含其他出厂目标32,33,34)
    # 包含: 原水(0-2) + 滤前(3,17) + 滤后(16) + 滤格(4-15,18-29) + 清水池(30) + 出厂压力(31) + 出厂流量(35) + dose + 自己
    32: [0, 1, 2, 3, 16, 17] + list(range(4, 16)) + list(range(18, 30)) + [30, 31, 32, 35, 36, 37],

    # 出厂ph: 同上
    33: [0, 1, 2, 3, 16, 17] + list(range(4, 16)) + list(range(18, 30)) + [30, 31, 33, 35, 36, 37],

    # 出厂浊度: 同上
    34: [0, 1, 2, 3, 16, 17] + list(range(4, 16)) + list(range(18, 30)) + [30, 31, 34, 35, 36, 37],
}


def build_prior_mask_38ch() -> torch.Tensor:
    """
    构建38通道的先验掩码
    返回: [6, 38] 的tensor，6个目标 x 38个通道
    """
    n_targets = len(TARGET_INDICES)
    n_channels = 38

    mask = torch.zeros(n_targets, n_channels)

    for i, tgt_idx in enumerate(TARGET_INDICES):
        visible = VISIBLE_CHANNELS[tgt_idx]
        for ch in visible:
            if 0 <= ch < n_channels:
                mask[i, ch] = 1.0

    return mask


# =========================
# 1) 目标特定通道选择器
# =========================
class TargetSpecificChannelSelector(nn.Module):
    """
    为每个目标特征学习独立的通道注意力权重
    """

    def __init__(
            self,
            n_channels: int = 38,
            n_targets: int = 6,
            target_indices: list = None,
            selection_mode: str = "soft",
            topk: int = 10,
            temperature: float = 1.0,
            prior_mask: torch.Tensor = None,
            prior_strength: float = 5.0,
    ):
        super().__init__()
        self.n_channels = n_channels
        self.n_targets = n_targets
        self.target_indices = target_indices if target_indices else TARGET_INDICES
        self.selection_mode = selection_mode
        self.topk = min(topk, n_channels)
        self.temperature = temperature
        self.prior_strength = prior_strength

        # 可学习的通道权重 logits [n_targets, n_channels]
        self.channel_logits = nn.Parameter(torch.zeros(n_targets, n_channels))

        # 注册先验掩码
        if prior_mask is not None:
            self.register_buffer("prior_mask", prior_mask)
            # 不可见通道初始化为很大的负值
            self.register_buffer("prior_bias", (prior_mask - 1.0) * prior_strength)
        else:
            self.register_buffer("prior_mask", None)
            self.register_buffer("prior_bias", None)

        self._init_weights()

    def _init_weights(self):
        nn.init.uniform_(self.channel_logits, -0.1, 0.1)

    def forward(self, x_enc: torch.Tensor = None) -> torch.Tensor:
        """
        返回每个目标的通道权重 [n_targets, n_channels]
        """
        logits = self.channel_logits

        # 加入先验偏置
        if self.prior_bias is not None:
            logits = logits + self.prior_bias

        if self.selection_mode == "soft":
            weights = F.softmax(logits / self.temperature, dim=-1)

        elif self.selection_mode == "hard_topk":
            if self.training:
                weights = F.softmax(logits / self.temperature, dim=-1)
            else:
                weights = torch.zeros_like(logits)
                _, topk_idx = torch.topk(logits, self.topk, dim=-1)
                weights.scatter_(1, topk_idx, 1.0 / self.topk)

        elif self.selection_mode == "hard_mask":
            if self.prior_mask is not None:
                soft_weights = F.softmax(logits / self.temperature, dim=-1)
                weights = soft_weights * self.prior_mask
                weights = weights / (weights.sum(dim=-1, keepdim=True) + 1e-8)
            else:
                weights = F.softmax(logits / self.temperature, dim=-1)

        else:
            weights = F.softmax(logits / self.temperature, dim=-1)

        return weights

    def get_effective_weights(self) -> torch.Tensor:
        with torch.no_grad():
            return self.forward()


# =========================
# 2) 通道加权融合层
# =========================
class ChannelWeightedFusion(nn.Module):
    """
    使用目标特定的通道权重对编码特征进行加权融合
    """

    def __init__(self, d_model: int, n_targets: int):
        super().__init__()
        self.d_model = d_model
        self.n_targets = n_targets

    def forward(
            self,
            enc_out: torch.Tensor,
            channel_weights: torch.Tensor,
            n_vars: int,
            batch_size: int
    ) -> torch.Tensor:
        """
        enc_out: [B*C, patch_num, d_model]
        channel_weights: [n_targets, C]
        返回: [B, n_targets, patch_num, d_model]
        """
        C = n_vars
        patch_num = enc_out.shape[1]
        d_model = enc_out.shape[2]

        # [B*C, patch_num, d_model] -> [B, C, patch_num, d_model]
        enc_reshaped = enc_out.view(batch_size, C, patch_num, d_model)

        # weights: [n_targets, C] -> [n_targets, 1, C, 1, 1]
        weights = channel_weights.view(self.n_targets, C, 1, 1)

        # enc: [B, C, patch_num, d_model] -> [1, B, C, patch_num, d_model]
        enc_expanded = enc_reshaped.unsqueeze(0)

        # broadcast multiply and sum over C
        weights_expanded = weights.unsqueeze(1)
        weighted = enc_expanded * weights_expanded
        fused = weighted.sum(dim=2)  # [n_targets, B, patch_num, d_model]

        # -> [B, n_targets, patch_num, d_model]
        fused = fused.permute(1, 0, 2, 3)

        return fused


# =========================
# 3) 目标特定预测头
# =========================
class TargetSpecificHead(nn.Module):
    """
    每个目标使用独立的预测头
    """

    def __init__(self, n_targets: int, d_model: int, patch_num: int, pred_len: int, dropout: float = 0.1):
        super().__init__()
        self.n_targets = n_targets
        self.pred_len = pred_len

        nf = d_model * patch_num

        self.heads = nn.ModuleList([
            nn.Sequential(
                nn.Flatten(start_dim=-2),
                nn.Linear(nf, pred_len),
                nn.Dropout(dropout)
            )
            for _ in range(n_targets)
        ])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [B, n_targets, patch_num, d_model]
        return: [B, pred_len, n_targets]
        """
        outputs = []
        for i, head in enumerate(self.heads):
            out_i = head(x[:, i, :, :])
            outputs.append(out_i)

        output = torch.stack(outputs, dim=-1)
        return output


# =========================
# 4) 标准Flatten Head
# =========================
class FlattenHead(nn.Module):
    def __init__(self, n_vars, nf, target_window, head_dropout=0.0):
        super().__init__()
        self.n_vars = n_vars
        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, target_window)
        self.dropout = nn.Dropout(head_dropout)

    def forward(self, x):
        x = self.flatten(x)
        x = self.linear(x)
        x = self.dropout(x)
        return x


# =========================
# 5) Model 类 (TFB兼容命名)
# =========================
class PatchTST(nn.Module):
    """
    PatchTST with Target-Specific Channel Selection
    适配TFB框架，类名为Model
    """

    def __init__(self, configs):
        super().__init__()
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.patch_len = getattr(configs, "patch_len", 16)
        self.stride = getattr(configs, "stride", 8)
        self.d_model = configs.d_model
        self.enc_in = configs.enc_in

        # ========== 通道选择配置 ==========
        self.use_channel_selection = getattr(configs, "use_channel_selection", True)
        self.selection_mode = getattr(configs, "selection_mode", "soft")
        self.topk_channels = getattr(configs, "topk_channels", 10)
        self.selection_temperature = getattr(configs, "selection_temperature", 1.0)
        self.prior_strength = getattr(configs, "prior_strength", 5.0)

        # 目标索引
        self.target_indices = getattr(configs, "target_indices", TARGET_INDICES)
        self.n_targets = len(self.target_indices)

        # 原水特征索引
        self.raw_indices = getattr(configs, "raw_indices", RAW_INDICES)

        # 先验掩码
        prior_mask = getattr(configs, "channel_prior_mask", None)
        if prior_mask is None and self.use_channel_selection:
            prior_mask = build_prior_mask_38ch()

        # ========== Patch Embedding ==========
        padding = self.stride
        self.patch_embedding = PatchEmbedding(
            self.d_model, self.patch_len, self.stride, padding, configs.dropout
        )

        self.patch_num = int((self.seq_len - self.patch_len) / self.stride + 2)
        self.head_nf = self.d_model * self.patch_num

        # ========== 目标特定通道选择器 ==========
        if self.use_channel_selection and self.n_targets > 0:
            self.channel_selector = TargetSpecificChannelSelector(
                n_channels=self.enc_in,
                n_targets=self.n_targets,
                target_indices=self.target_indices,
                selection_mode=self.selection_mode,
                topk=self.topk_channels,
                temperature=self.selection_temperature,
                prior_mask=prior_mask,
                prior_strength=self.prior_strength,
            )
            self.channel_fusion = ChannelWeightedFusion(
                d_model=self.d_model,
                n_targets=self.n_targets,
            )
            self.target_head = TargetSpecificHead(
                n_targets=self.n_targets,
                d_model=self.d_model,
                patch_num=self.patch_num,
                pred_len=self.pred_len,
                dropout=configs.dropout
            )
        else:
            self.channel_selector = None
            self.channel_fusion = None
            self.target_head = None

        # ========== Transformer Encoder ==========
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=configs.output_attention,
                        ),
                        self.d_model,
                        configs.n_heads,
                    ),
                    self.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.LayerNorm(self.d_model),
        )

        # ========== 标准Head ==========
        self.standard_head = FlattenHead(
            self.enc_in, self.head_nf, self.pred_len, head_dropout=configs.dropout
        )

    def forecast(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        """
        x_enc: [B, L, C]
        return: [B, pred_len, C]
        """
        B, L, C = x_enc.shape

        # -------- Instance Normalization --------
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc_norm = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc_norm, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc_norm = x_enc_norm / stdev

        # -------- Patch Embedding --------
        x_patch = x_enc_norm.permute(0, 2, 1)  # [B, C, L]
        enc_out, n_vars = self.patch_embedding(x_patch)  # [B*C, patch_num, d_model]

        # -------- Transformer Encoder --------
        enc_out, _ = self.encoder(enc_out)  # [B*C, patch_num, d_model]

        # -------- 目标特定通道选择 --------
        if self.use_channel_selection and self.channel_selector is not None:
            # 获取通道权重
            channel_weights = self.channel_selector(x_enc_norm)  # [n_targets, C]

            # 加权融合
            fused_out = self.channel_fusion(enc_out, channel_weights, n_vars, B)
            # [B, n_targets, patch_num, d_model]

            # 目标预测
            target_out = self.target_head(fused_out)  # [B, pred_len, n_targets]

            # 构建完整输出：先用标准head预测所有通道
            enc_out_reshaped = enc_out.view(B, n_vars, enc_out.shape[-2], enc_out.shape[-1])
            enc_out_reshaped = enc_out_reshaped.permute(0, 1, 3, 2)
            standard_out = self.standard_head(enc_out_reshaped)  # [B, C, pred_len]
            dec_out = standard_out.permute(0, 2, 1)  # [B, pred_len, C]

            # 目标通道用专门的预测结果覆盖
            for i, idx in enumerate(self.target_indices):
                dec_out[:, :, idx] = target_out[:, :, i]

        else:
            # 标准模式
            enc_out = enc_out.view(B, n_vars, enc_out.shape[-2], enc_out.shape[-1])
            enc_out = enc_out.permute(0, 1, 3, 2)
            dec_out = self.standard_head(enc_out)
            dec_out = dec_out.permute(0, 2, 1)

        # -------- De-Normalization --------
        dec_out = dec_out * stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1)
        dec_out = dec_out + means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1)

        return dec_out

    def get_channel_weights(self) -> torch.Tensor:
        """获取学到的通道权重"""
        if self.channel_selector is not None:
            return self.channel_selector.get_effective_weights().detach().cpu()
        return None

    def get_channel_importance_report(self) -> str:
        """生成通道重要性报告"""
        weights = self.get_channel_weights()
        if weights is None:
            return "Channel selection not enabled"

        report = []
        report.append("=" * 60)
        report.append("通道重要性分析报告")
        report.append("=" * 60)

        for i, tgt_idx in enumerate(self.target_indices):
            tgt_name = FEATURE_NAMES[tgt_idx] if tgt_idx < len(FEATURE_NAMES) else f"Target_{tgt_idx}"
            w = weights[i].numpy()

            report.append(f"\n目标: {tgt_name} (idx={tgt_idx})")
            report.append("-" * 40)

            sorted_idx = w.argsort()[::-1]
            report.append("Top 10 重要通道:")
            for rank, ch_idx in enumerate(sorted_idx[:10]):
                ch_name = FEATURE_NAMES[ch_idx] if ch_idx < len(FEATURE_NAMES) else f"Ch_{ch_idx}"
                report.append(f"  {rank + 1}. {ch_name}: {w[ch_idx]:.4f}")

        return "\n".join(report)

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None, mask=None):
        if self.task_name in ["long_term_forecast", "short_term_forecast"]:
            return self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)


# =========================
# 辅助函数
# =========================
def print_visible_channels_info():
    """打印每个目标的可见通道信息"""
    print("=" * 70)
    print("目标特征可见通道配置")
    print("=" * 70)

    for tgt_idx in TARGET_INDICES:
        tgt_name = FEATURE_NAMES[tgt_idx]
        visible = VISIBLE_CHANNELS[tgt_idx]
        visible_names = [FEATURE_NAMES[i] for i in visible if i < len(FEATURE_NAMES)]

        print(f"\n{tgt_name} (idx={tgt_idx}):")
        print(f"  可见通道数: {len(visible)}")
        print(f"  可见通道索引: {visible}")
        print(f"  可见通道名称:")
        for i, name in enumerate(visible_names):
            print(f"    {i + 1}. {name}")


def visualize_channel_weights(model, save_path=None):
    """可视化通道权重热力图"""
    import matplotlib.pyplot as plt
    import numpy as np

    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False

    weights = model.get_channel_weights()
    if weights is None:
        print("Channel selection not enabled")
        return

    weights = weights.numpy()

    fig, ax = plt.subplots(figsize=(18, 8))

    im = ax.imshow(weights, cmap='YlOrRd', aspect='auto')

    ax.set_yticks(range(len(TARGET_INDICES)))
    ax.set_yticklabels([FEATURE_NAMES[i] for i in TARGET_INDICES], fontsize=10)

    ax.set_xticks(range(len(FEATURE_NAMES)))
    ax.set_xticklabels(FEATURE_NAMES, rotation=45, ha='right', fontsize=8)

    ax.set_xlabel('输入通道', fontsize=12)
    ax.set_ylabel('预测目标', fontsize=12)
    ax.set_title('目标特定通道权重热力图', fontsize=14)

    plt.colorbar(im, label='权重')
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"图片已保存: {save_path}")

    plt.show()


def visualize_prior_mask(save_path=None):
    """可视化先验掩码"""
    import matplotlib.pyplot as plt

    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False

    mask = build_prior_mask_38ch().numpy()

    fig, ax = plt.subplots(figsize=(18, 8))

    im = ax.imshow(mask, cmap='Blues', aspect='auto', vmin=0, vmax=1)

    ax.set_yticks(range(len(TARGET_INDICES)))
    ax.set_yticklabels([FEATURE_NAMES[i] for i in TARGET_INDICES], fontsize=10)

    ax.set_xticks(range(len(FEATURE_NAMES)))
    ax.set_xticklabels(FEATURE_NAMES, rotation=45, ha='right', fontsize=8)

    ax.set_xlabel('输入通道', fontsize=12)
    ax.set_ylabel('预测目标', fontsize=12)
    ax.set_title('先验掩码 (基于水厂工艺流程)\n蓝色=可见, 白色=不可见', fontsize=14)

    plt.colorbar(im, label='可见性')
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"图片已保存: {save_path}")

    plt.show()


# =========================
# 测试代码
# =========================
if __name__ == "__main__":
    # 打印可见通道信息
    print_visible_channels_info()

    # 打印先验掩码统计
    mask = build_prior_mask_38ch()
    print("\n" + "=" * 70)
    print("先验掩码统计")
    print("=" * 70)
    for i, tgt_idx in enumerate(TARGET_INDICES):
        n_visible = mask[i].sum().item()
        tgt_name = FEATURE_NAMES[tgt_idx]
        print(f"{tgt_name}: {int(n_visible)}/38 通道可见")